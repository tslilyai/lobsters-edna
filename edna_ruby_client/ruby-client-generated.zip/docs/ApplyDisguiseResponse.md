# SwaggerClient::ApplyDisguiseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**did** | **Integer** |  | 

