# SwaggerClient::SavePseudoprincipalRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**did** | **Integer** |  | 
**old_uid** | **String** |  | 
**new_uid** | **String** |  | 
**record_bytes** | **Array&lt;Integer&gt;** |  | 

