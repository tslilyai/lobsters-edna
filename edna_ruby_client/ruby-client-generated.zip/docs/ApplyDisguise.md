# SwaggerClient::ApplyDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | **String** |  | 
**disguise_json** | **String** |  | 
**tableinfo_json** | **String** |  | 
**password** | **String** |  | 
**guisegen_json** | **String** |  | 

