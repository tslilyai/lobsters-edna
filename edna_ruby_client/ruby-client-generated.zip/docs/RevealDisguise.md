# SwaggerClient::RevealDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tableinfo_json** | **String** |  | 
**guisegen_json** | **String** |  | 
**password** | **String** |  | 

