# SwaggerClient::RegisterPrincipal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **String** |  | 
**pw** | **String** |  | 

