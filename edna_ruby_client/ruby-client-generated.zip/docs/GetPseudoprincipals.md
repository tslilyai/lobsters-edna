# SwaggerClient::GetPseudoprincipals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | **String** |  | 

