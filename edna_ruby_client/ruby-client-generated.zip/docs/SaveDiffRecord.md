# SwaggerClient::SaveDiffRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **String** |  | 
**did** | **Integer** |  | 
**data** | **Array&lt;Integer&gt;** |  | 

