# SwaggerClient::RegisterPrincipalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**share** | **String** |  | 

