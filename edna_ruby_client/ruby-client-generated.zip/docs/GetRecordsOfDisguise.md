# SwaggerClient::GetRecordsOfDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**did** | **Integer** |  | 
**decrypt_cap** | **Array&lt;Integer&gt;** |  | 

